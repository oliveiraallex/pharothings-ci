I describe all objects which responds to particular message.

	(10@230) should respondTo: #x

My instances can be created by 

	SpecOfObjectResponsibility requiredMessage: #x 
 
Internal Representation and Key Implementation Points.

    Instance Variables
	requiredMessage:		<Symbol>
