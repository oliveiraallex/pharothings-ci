I am just example of real ghost implementation which is used in tests. 
I define stub behaviour GHGhostBehaviourStub to just return intercepting messages as it result.  I implement new method which is initialized behaviour.
 
Internal Representation and Key Implementation Points.

    Instance Variables
	ghostBehaviour:		<GHGhostBehaviour>