I am special mock to help work with other objects by explicit messages.
I created to not register myself as environment object. Because I am just helper