I represent simple value return from message send

Internal Representation and Key Implementation Points.

    Instance Variables
	value:		<Object>