I describe all objects of particular class.

	(10@30) should beInstanceOf: Point