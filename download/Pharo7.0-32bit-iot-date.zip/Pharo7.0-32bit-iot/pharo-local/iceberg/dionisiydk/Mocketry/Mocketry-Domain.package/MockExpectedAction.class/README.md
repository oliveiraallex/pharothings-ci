I represent abstract mock expectation action which should be executed when corresponding message send will be intercepted.

My subclasses should define method 
	 executeFor: aMockOccurredMessage