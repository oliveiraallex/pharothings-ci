I am special DSL class to get argument captures:

	Arg argName
	
where #argName is name of argument defined by message send.

	Arg connection 
	Arg x