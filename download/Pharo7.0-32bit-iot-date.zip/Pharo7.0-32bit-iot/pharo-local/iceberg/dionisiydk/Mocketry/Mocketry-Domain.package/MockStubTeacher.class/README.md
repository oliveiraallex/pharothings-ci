I am special helper mock role which intercepts all messages to produce expectations for my object.

I am used during stub teaching: 
	mock stub someMessage willReturn: 3