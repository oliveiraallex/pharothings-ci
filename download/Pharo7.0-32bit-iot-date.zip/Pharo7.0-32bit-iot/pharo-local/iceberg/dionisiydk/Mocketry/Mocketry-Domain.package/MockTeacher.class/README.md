I am mock role which force mocks to learn all intercepted messages as expectation. 
With me MockBehaviour will create new MockExpectedMessage instance to define expected behaviour. 

I am defined as singleton:
	MockTeacher default