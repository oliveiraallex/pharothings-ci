I am special ghost to study all messages which sent to me. On any messages I ask my teacher for real implementations for it. I save it and execute it. This behaviour is implemented by my learning instance.
 
Internal Representation and Key Implementation Points.

    Instance Variables
	learning:		<Learning>