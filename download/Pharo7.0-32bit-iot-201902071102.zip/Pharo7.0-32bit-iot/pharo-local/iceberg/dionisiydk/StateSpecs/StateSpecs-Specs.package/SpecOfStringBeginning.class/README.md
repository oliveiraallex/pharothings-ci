I describe strings which begin with particular substring.

	'some test string' should beginWith: 'some'.
	'some test string' should beginWith: 'Some' caseSensitive: true