I am root of hierarchy to object value itself.
 
Internal Representation and Key Implementation Points.

    Instance Variables
	requiredValue:		<Object>
