I represent expected exception which should be signalled when corresponding message send wil be intercepted.

My instances can be created by 
	MockExpectedException exception: Error
or with exception isntance:
	MockExpectedException exception: anError
 
Internal Representation and Key Implementation Points.

    Instance Variables
	exception:		<Exception>