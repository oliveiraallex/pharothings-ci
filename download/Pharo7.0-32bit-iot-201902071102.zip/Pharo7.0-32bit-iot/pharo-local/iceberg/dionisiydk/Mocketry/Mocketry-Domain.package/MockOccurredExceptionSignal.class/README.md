I represent signalled exception during message send.
 
Internal Representation and Key Implementation Points.

    Instance Variables
	exception:		<Exception>