I drive execution of should expression to select appropriate pragmas which can be used for current syntax path

Public API and Key Messages

- acceptMessage: aMessage   
- isClauseComplete 
- createTarget
 
Internal Representation and Key Implementation Points.

    Instance Variables
	currentMessage:		<Message>
	progress:		<Integer>
	targetPragmas:		<Collection of<Pragma>>