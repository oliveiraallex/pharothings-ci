I specify any posslble object. 
I should be used directly as class to successfully validate any object.

	(Any matches:  nil) = true
	(Any matches:  Object new) = true