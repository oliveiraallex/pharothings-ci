I describe strings which include particular substring.

	'some test string' should includeSubstring: 'test'.
	'some test string' should includeSubstring: 'Test' caseSensitive: true