I describe all objects which are kind of particular class.

	#string should beKindOf: String