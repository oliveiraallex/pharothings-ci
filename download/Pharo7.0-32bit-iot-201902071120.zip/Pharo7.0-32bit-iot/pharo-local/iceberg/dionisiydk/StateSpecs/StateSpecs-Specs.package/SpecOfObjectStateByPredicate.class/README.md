I describe all objects which satisfy particular predicate.

	10 should satisfy: [ :num | num > 2 ] 

My instances can be created by: 
	
	SpecOfObjectStateByPredicate from:  [ :num | num > 2 ] 
	 
Internal Representation and Key Implementation Points.

    Instance Variables
	predicate:		<BlockClosure>
