I implement disjunction of specifications.

I can be created by | message to spec:
	
	(Instance of: String) | (Instance of: Integer)