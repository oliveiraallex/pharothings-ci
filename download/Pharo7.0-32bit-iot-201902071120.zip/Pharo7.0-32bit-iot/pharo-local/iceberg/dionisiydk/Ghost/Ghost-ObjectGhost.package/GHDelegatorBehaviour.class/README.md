I am delegation behaviour for ghost. I just resend intercepted message to my target object

My instance can be creation by:
	GHDelegatorBehaviour metaLevel: aGHMetaLevel target: anObject
	GHDelegatorBehaviour target: anObject

Internal Representation and Key Implementation Points.

    Instance Variables
	metaLevel:		<GHMetaLevel>
	target:		<Object>