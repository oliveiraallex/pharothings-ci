I represent default message send result when special mock is returned.

Internal Representation and Key Implementation Points.

    Instance Variables
	returnedMock:		<MockForMessageReturn>