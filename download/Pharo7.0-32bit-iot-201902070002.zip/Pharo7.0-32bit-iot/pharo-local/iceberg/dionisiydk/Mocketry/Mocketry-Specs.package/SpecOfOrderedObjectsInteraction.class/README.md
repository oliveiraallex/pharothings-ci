I specify ordered group of expected message specs. (as conjunction).
I am valid for group of message only if they occurred in exact order which defined by my contents.

My contents are SpecOfExpectedMessage