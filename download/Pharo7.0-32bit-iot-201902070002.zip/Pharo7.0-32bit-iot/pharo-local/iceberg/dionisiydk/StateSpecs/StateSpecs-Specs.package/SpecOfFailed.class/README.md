I am exception to signal specification failure.

SpecOfValidationFailure signals me by #raise method.
	validationResult raise
	
Internal Representation and Key Implementation Points.

    Instance Variables
	reason:		<SpecOfValidationFailure>
