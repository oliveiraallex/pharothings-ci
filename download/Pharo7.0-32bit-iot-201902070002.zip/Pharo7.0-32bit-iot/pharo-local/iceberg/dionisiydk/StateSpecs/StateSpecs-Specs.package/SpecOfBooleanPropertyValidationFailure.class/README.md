I represent object validation failure for boolean property.
I provide suitable description for incorrect property