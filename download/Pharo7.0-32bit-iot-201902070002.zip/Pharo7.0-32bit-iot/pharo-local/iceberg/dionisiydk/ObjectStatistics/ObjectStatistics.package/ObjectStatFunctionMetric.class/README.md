I am metric which accumulate given function value over all objects set.

Internal Representation and Key Implementation Points.

    Instance Variables
	functionBlock:		<BlockClosure>
