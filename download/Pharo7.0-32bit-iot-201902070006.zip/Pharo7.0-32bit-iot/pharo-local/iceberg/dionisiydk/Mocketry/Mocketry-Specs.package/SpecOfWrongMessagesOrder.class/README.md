I represent failure of SpecOfOrderedObjetsInteraction when actual messages order was wrong

My wrongMessage variable contains spec of message which was occurred in wrong time.

Internal Representation and Key Implementation Points.

    Instance Variables
	wrongMessage:		<SpecOfExpectedMessage>