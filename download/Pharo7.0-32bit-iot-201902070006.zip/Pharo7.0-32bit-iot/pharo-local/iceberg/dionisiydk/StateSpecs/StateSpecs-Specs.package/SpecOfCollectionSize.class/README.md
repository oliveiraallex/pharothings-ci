I describe collections of particular size.

	#(1 2) should haveSize: 2

My instances can be created by: 

	SpecOfCollectionSize requiredSize: 2

Internal Representation and Key Implementation Points.
	
    Instance Variables
	requiredSize:		<Integer>