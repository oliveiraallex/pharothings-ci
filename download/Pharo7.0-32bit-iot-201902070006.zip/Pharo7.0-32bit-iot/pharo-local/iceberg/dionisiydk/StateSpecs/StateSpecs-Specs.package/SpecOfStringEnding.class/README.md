I describe strings which end with particular substring.

	'some string for test' should endWith: 'test'.
	'some string for test' should endWith: 'Test' caseSensitive: true