I am special mock which are returned from messages as default value when no expectation is defined.

I contain message which was produced me. And my printed value includes information about it.

Also I try to mimic false in ifTrue/ifFalse conditions. When I detect it I replace myself with false.
And I try to do same logic for arithmetics operations. I replace myself by zero when I detect that numbers logic is performed with me.
 
Internal Representation and Key Implementation Points.

    Instance Variables
	message:		<MockOccurredMessage>