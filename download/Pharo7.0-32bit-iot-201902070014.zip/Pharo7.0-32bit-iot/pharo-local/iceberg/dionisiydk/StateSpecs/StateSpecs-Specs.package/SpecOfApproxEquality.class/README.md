I describe objects (numbers) which are equal to my required value with particular accuracy.

	1.1 should equal: 1 within: 0.2

My instances can be created by 

	SpecOfApproxEquality to: 1 within: 0.2
		
Internal Representation and Key Implementation Points.

    Instance Variables
	accuracy:		<Number>