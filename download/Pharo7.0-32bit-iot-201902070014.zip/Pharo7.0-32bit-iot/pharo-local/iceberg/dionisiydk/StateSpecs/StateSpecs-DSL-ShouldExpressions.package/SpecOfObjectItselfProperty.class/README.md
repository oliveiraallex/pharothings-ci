I represent object itself to be root parent of SpecOfObjectProperty.

My instances can be created by 
	
	SpecOfObjectItselfProperty of: anObject
	
Public API and Key Messages

- subPropertyAt:
- value
- stringForSpecTitle 
 
Internal Representation and Key Implementation Points.

    Instance Variables
	value:		<Object>
