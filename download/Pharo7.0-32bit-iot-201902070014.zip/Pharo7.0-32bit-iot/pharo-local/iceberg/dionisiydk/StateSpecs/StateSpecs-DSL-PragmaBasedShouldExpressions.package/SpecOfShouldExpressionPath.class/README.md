I represent path inside should expression

Internal Representation and Key Implementation Points.

    Instance Variables
	arguments:		<Object>
	clause:		<Object>