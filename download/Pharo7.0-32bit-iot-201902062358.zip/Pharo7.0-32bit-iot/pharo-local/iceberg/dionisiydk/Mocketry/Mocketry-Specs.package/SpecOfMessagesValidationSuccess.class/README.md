I represent successful result of occurred messages validation  by SpecOfOccurredMessages spec.

I needed to supply list of occurred messages which satisfying spec. Then this information can be used in other more complex specs.

Internal Representation and Key Implementation Points.

    Instance Variables
	occurredMessages:		<Collection of <MockOccurredMessage>>