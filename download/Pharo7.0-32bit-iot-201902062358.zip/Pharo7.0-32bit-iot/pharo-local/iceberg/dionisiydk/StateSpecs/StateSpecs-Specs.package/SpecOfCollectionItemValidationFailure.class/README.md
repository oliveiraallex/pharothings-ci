I represent collection validation failure for expected item. 
I provide more suitable description about wrong collection item.

Internal Representation and Key Implementation Points.

    Instance Variables
	wrongItem:		<Object>