I am used to create internal property instance of given object which then can be validated:

	(10@3) which x should equal: 10
	
which here returns me. 

Internal Representation and Key Implementation Points.

    Instance Variables
	property:		<SpecOfObjectProperty>
