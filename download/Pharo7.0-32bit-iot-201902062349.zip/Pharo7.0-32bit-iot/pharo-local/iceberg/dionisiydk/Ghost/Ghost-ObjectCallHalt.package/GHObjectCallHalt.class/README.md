I halt any call to object.

First I recover mutated object from my mutation.
Then I install breakpoint into target method and activate it.
I use special trick to remove ghost related stacks from context to skip it from users completelly