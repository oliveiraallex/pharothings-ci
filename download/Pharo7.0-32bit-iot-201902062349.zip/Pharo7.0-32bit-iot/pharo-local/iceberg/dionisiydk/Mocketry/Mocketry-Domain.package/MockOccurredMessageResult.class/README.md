I am a root of occurred message results.
My subclasses represent different kind of results which was received during occurred message execution