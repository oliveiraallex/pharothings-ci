I implement special hook to validate internal object properties by should expressions. I am created for property validation:
	
	(1@0) where x should equal: 1

should here returns me.

I override few methods to push property information to given objects  	

Internal Representation and Key Implementation Points.

    Instance Variables
	receiver:		<SpecOfObjectProperty>