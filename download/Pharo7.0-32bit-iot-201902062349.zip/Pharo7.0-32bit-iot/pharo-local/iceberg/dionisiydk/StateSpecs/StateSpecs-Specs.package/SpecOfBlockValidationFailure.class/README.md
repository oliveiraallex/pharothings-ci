I represent block validation failure for expected exception. 
I am implemented to support passing errors logic which described in SpecOfBlockFailure comment.
 
Internal Representation and Key Implementation Points.

    Instance Variables
	errorValidationResult:		<SpecOfValidationFailure>