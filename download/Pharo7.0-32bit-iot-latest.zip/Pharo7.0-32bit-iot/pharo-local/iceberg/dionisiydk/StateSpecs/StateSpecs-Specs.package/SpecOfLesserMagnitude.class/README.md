I describe magnitudes which are less than my required value.

	1 should beLessThan: 10

My instances can be created by 

	SpecOfLesserMagnitude than: 10