I am root of hierarchy of specifications for objects relationship

My instances can be created by 

	SpecOfObjectRelationship requiredClass: String

Internal Representation and Key Implementation Points.

    Instance Variables
	requiredClass:		<Class>