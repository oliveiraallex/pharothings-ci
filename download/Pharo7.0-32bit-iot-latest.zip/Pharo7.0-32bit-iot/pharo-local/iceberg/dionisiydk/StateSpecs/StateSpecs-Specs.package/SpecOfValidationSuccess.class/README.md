I represent successful spec validation.

My superclass define singleton for me 

	SpecOfValidationResult success