I implement negation of specifications.

I can be created by:
	
	SpecOfNegation of: (Instance of: String) and: (Instance of: Integer)