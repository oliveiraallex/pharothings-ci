I describe magnitudes which are greater than my required value.

	10 should beGreaterThan: 1

My instances can be created by 

	SpecOfGreaterMagnitude than: 1