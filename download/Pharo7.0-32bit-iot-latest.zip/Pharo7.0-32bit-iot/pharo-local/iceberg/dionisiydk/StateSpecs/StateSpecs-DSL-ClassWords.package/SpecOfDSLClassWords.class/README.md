I am created to group all DSL words in one hierarchy.
My subclasses only provide better syntax of specs creation sentences.
They can define multiple methods to return different kind of specs.

Everything are implemented on class side