I am trait for ghost implementations which can not be nil.

Most of my messages (ifNil friends) are never sent to objects because they are special. But I define it here to explicitly mention that NotNilGhost should not intercept them