I represent slice of overall objects statistics.
I am created by dimensions for every objects coordinate to maintain own sub statistics..

Public API and Key Messages

- accumulate: anObject
it adds given object to my own statistics.   
 
Internal Representation and Key Implementation Points.

    Instance Variables
	coordinate:		<Object>
	statistics:		<ObjectStatistics>


    Implementation Points