I am helper objects to define statistics dimensions tree by fluent api.
 
Internal Representation and Key Implementation Points.

    Instance Variables
	dimensions:		<OrderedCollection>
	objectsSpec:		<SpecOfObjectStat>