I am metric which count how many different properties objects have.
For example I could be used to count receivers of messages set.

Internal Representation and Key Implementation Points.

    Instance Variables
	measuredProperties:		<IdentitySet>
	propertyBlock:		<BlockClosure>
