I represent message send result as root parent of SpecOfObjectProperty.

My instances can be created by 
	
	SpecOfOccurredResultProperty message: aMockOccurredMessage

Internal Representation and Key Implementation Points.

    Instance Variables
	message:		<MockOccurredMessage>