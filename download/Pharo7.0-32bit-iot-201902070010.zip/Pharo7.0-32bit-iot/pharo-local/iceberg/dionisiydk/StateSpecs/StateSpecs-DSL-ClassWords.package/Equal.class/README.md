I am DSL word for better syntax for specs creation sentences.

Look at class side