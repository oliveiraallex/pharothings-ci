I implement conjunction of specifications.

I can be created by & message to spec:
	
	(Instance of: String) & (Satisfying for: [:o | true])