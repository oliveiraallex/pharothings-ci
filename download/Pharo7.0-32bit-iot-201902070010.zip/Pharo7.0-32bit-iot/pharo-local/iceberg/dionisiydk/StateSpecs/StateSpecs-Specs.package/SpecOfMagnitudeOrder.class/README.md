I am root of hierrarchy of magnitude order specifications.

Variable isStrong specifes strong comparison for order check  

Internal Representation and Key Implementation Points.

    Instance Variables
	isStrong:		<Boolean>